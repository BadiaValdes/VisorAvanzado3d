///////// variables auxiliares ///////
let
action,
actions={},
ambientLight,
ani = true,
box,
CameraBox,
container =  document.getElementById('model-content'),
camera,
controls,
fadeTime = 0.5,
hasani = true,
renderer,
rotation = false,
scene,
stats,
url2 = 'models/f.glb',
mainLight,
model,
objectLoader,
preload = document.getElementById("preload"),
color = 0x000000,
rotateSpeed = 0.01;

//////Elementos del dom
let 
    wire = document.getElementById('wire'),
    ////
    ani_iniciar = document.getElementById('ani_iniciar'),
    ani_detener = document.getElementById('ani_detener'),
    ani_reanudar = document.getElementById('ani_reanudar'),
    ani_pausar = document.getElementById('ani_pausar'),
    animatioClip = document.getElementById('animatioClip'),
    animatioWrapper = document.getElementById('animacion'),
    ////
    rot_reiniciar = document.getElementById('rot_reiniciar'),
    rot_velocidad = document.getElementById('rot_velocidad'),
    rot_iniciar = document.getElementById('rot_iniciar'),
    ////
    fondo = document.getElementById('fondo'),
    ////
    ld_intensidad = document.getElementById('ld_intensidad'),
    ld_color = document.getElementById('ld_color'),
    ld_posX = document.getElementById('ld_posX'),
    ld_posY = document.getElementById('ld_posY'),
    ld_posZ = document.getElementById('ld_posZ'),
    ////
    la_intensidad = document.getElementById('la_intensidad'),
    la_color = document.getElementById('la_color'),
    la_color_secundario = document.getElementById('la_color_secundario'),
    la_posX = document.getElementById('la_posX'),
    la_posY = document.getElementById('la_posY'),
    la_posZ = document.getElementById('la_posZ');

    /////
const
    clock = new THREE.Clock(), //animacion en tiempo real
    mixers = [];



///////// Clases auxiliares

class ModelCreator {

    MC_url;

    constructor (url)
    {
        this.MC_url = url;
    }

   
    Execute() {}
    MaterialWireframe(){}
}

class ModelCreatorOBJ extends ModelCreator {

    mtlLoader = new THREE.MTLLoader();
    loader = new THREE.OBJLoader();

    constructor (url)
    {
        super(url);
    }

   

    Execute() {
        
        
        var mtlURL = this.MC_url.replace(".obj",".mtl");
        console.log(mtlURL);
        const initialpos = new THREE.Vector3(0, 0, 0);
        var Mtlcarga = false;

        Mtlcarga = checkURL(mtlURL);
        
        
        if(Mtlcarga == true)
       {
            this.MTLLoad(mtlURL,this.loader,initialpos);
       }
       else
        {
            this.OBJLoad(this.loader,initialpos);
        }

     

        // the loader will report the loading progress to this function
       

        

    }

    MTLLoad(mtlURL,loader,initialpos)
    {
    
        this.mtlLoader.load(mtlURL, function(material) {
            
            material.preload();
            loader.setMaterials(material);

            const onLoad = (obj, position) => {
                console.log("Ejecutando")
                obj.position.copy(position);

                box = new THREE.Box3().setFromObject(obj);
                

                console.log(mtlURL);

                model = obj;
                       
                

                

                /*while(box.getParameter(camera.position).z < 9)
                camera.position.z += 50;*/

                while(camera.position.distanceTo(model.position) < Math.max(box.max.y, box.max.x, box.max.z) )
                {camera.position.z *= 6;}

                action = null;
                hasani = false;

                HideMe();

                preload.classList.remove("show");
                preload.classList.add("hide");

                controls.target = box.getCenter();
                controls.saveState();

                scene.add(obj);

                ControlDist();

            };
            loader.load(url2, obj => onLoad(obj, initialpos), onProgress, onError);
            }

            );
       

            const onProgress = () => {
                console.log("Cargando MTL....");
            };



            // the loader will send any error messages to this function, and we'll log
            // them to to console
            const onError = (errorMessage) => { alert("Error al cargar el archivo 3D"); };

            // load the first model. Each model is loaded asynchronously,
            // so don't make any assumption about which one will finish loading first
}

    OBJLoad(loader,initialpos)
    {           
            const onLoad = (obj, position) => {
                console.log("Ejecutando")

                box = new THREE.Box3().setFromObject(obj);


                //camera.position.z = box.max.z * 20;

                console.log(obj);

                model = obj;



                obj.position.copy(position);

                //obj.scale.set(0.2, 0.2, 0.2);

                
                

                //camera.position.z = box.distanceToPoint(camera.position);
                while(box.getParameter(camera.position).z < 9)
                camera.position.z += 50;

                action = null;
                hasani = false;

                HideMe();

                controls.target = box.getCenter();
                controls.saveState();

                preload.classList.remove("show");
                preload.classList.add("hide");
                scene.add(obj);
                ControlDist();

            };    
            // the loader will report the loading progress to this function
              
            

            const onProgress = () => {
                                
                console.log("Cargando OBJ....");
            };



            // the loader will send any error messages to this function, and we'll log
            // them to to console
            const onError = (errorMessage) => { alert("Error al cargar el archivo 3D"); };

            // load the first model. Each model is loaded asynchronously,
            // so don't make any assumption about which one will finish loading first
            loader.load(url2 , obj => onLoad(obj, initialpos), onProgress, onError);
    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {

                
                 
                    child.material.wireframe = !child.material.wireframe ? true : false;
                    
        
                
            }
        }
        );
            
    }

}

class ModelCreatorFBX extends ModelCreator {
     

    Execute() {
        var loader = new THREE.FBXLoader();

        const onLoad = (obj, position) => {

           
            console.log(obj);
            
            obj.position.copy(position);
            box = new THREE.Box3().setFromObject(obj);

            console.log("Cargando Modelo FBX");


            //camera.position.z = box.max.z * 20;

            //obj.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo

            //obj.material = new THREE.MeshBasicMaterial({ color: 0xf90338, wireframe: true });

            //CameraRePositioning(box.max.z + 50);
            while(camera.position.distanceTo(obj.position) <  Math.max(box.max.y, box.max.x, box.max.z))
            {camera.position.z *= 6;}

            console.log(Math.max(box.max.y, box.max.x, box.max.z))
            
            try {
                const mixer = new THREE.AnimationMixer(obj);
                mixers.push(mixer);
                const animation = obj.animations;

                for(var i = 0; i < animation.length; i++)
                {
                    let op = document.createElement("option");
                    action = mixer.clipAction(animation[i]);
                    actions[animation[i].name] = action;
                    op.text = animation[i].name;
                    op.value = animation[i].name;
                    animatioClip.appendChild(op);
                }

                action = mixer.clipAction(animation[0]);
                hasani = true;
                    

                
            } catch (e) {
                hasani = false
            }

            HideMe();

            


            model = obj;

  

            controls.target = box.getCenter();
            controls.saveState();

            preload.classList.remove("show");
            preload.classList.add("hide");

            scene.add(obj);

            ControlDist();

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("Cargando FBX....");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (e) => { 
            alert('On Error');
            alert(e); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        const parrotPosition = new THREE.Vector3(0, 0, 0);
        loader.load(this.MC_url, obj => onLoad(obj, parrotPosition), onProgress, onError);

    }

    MaterialWireframe() 
    {
        model.traverse(function (child) {
            if ( child.material ) {

                
                    if(child.material.wireframe == false)
                    child.material.wireframe = true;
                    else
                    child.material.wireframe = false;
        
                
            }
        }
        );
    }

}

class ModelCreatorSTL extends ModelCreator {


    Execute() {
        var material = new THREE.MeshPhongMaterial({ color: 0xc3c3c3 });
        var loader = new THREE.STLLoader();

        const onLoad = (obj) => {

           
            var meshMaterial = material;
            if (obj.hasColors) {
                meshMaterial = new THREE.MeshPhongMaterial({ opacity: obj.alpha, vertexColors: THREE.VertexColors });
            }
            var mesh = new THREE.Mesh(obj, meshMaterial);

            mesh.position.set(0, 0, 0);
            mesh.rotation.set(-Math.PI / 2, 0, 0);
            mesh.scale.set(1, 1, 1);

            box = new THREE.Box3().setFromObject(mesh);

            while(camera.position.distanceTo(mesh.position) < box.max.z * 5)
                {camera.position.z += 1;}

            /*while(box.distanceToPoint(camera.position.z) < 500 )
                
                camera.position.z += 1;*/


            hasani = false;
            HideMe();

            preload.classList.remove("show");
            preload.classList.add("hide");

            model = mesh;

            controls.target = box.getCenter();
            controls.saveState();

            scene.add(mesh);

            ControlDist();

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("cargando STL");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (errorMessage) => { alert(errorMessage); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        loader.load(this.MC_url, obj => onLoad(obj), onProgress, onError);

    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {                    
                    child.material.wireframe = !child.material.wireframe ? true : false;          
            }
        }
        );
    }

}

class ModelCreatorGLTF extends ModelCreator {


    Execute() {
        var loader = new THREE.GLTFLoader();
        var dracoLoader = new THREE.DRACOLoader(loader);
          
        loader.setDRACOLoader(dracoLoader);
    
        

        const onLoad = (obj, position) => {

            

            
            console.log(obj);

            model = obj.scene.children[0];
            model.position.copy(position);

            
            box = new THREE.Box3().setFromObject(model);
             // mover el centro del objeto al medio del mismo


            //camera.position.set(0,0,box.max.z * 4);
           // while(box.getParameter(camera.position).z < 2)
           //     camera.position.z += 50;
            //CameraRePositioning(box.max.z + 100); //nuevo agregar

            while(camera.position.distanceTo(model.position) <  Math.max(box.max.y, box.max.x, box.max.z))
            {camera.position.z *= 6;}

   

            try {
                const animation = obj.animations;

                const mixer = new THREE.AnimationMixer(model);
                mixers.push(mixer);
                
                for(var i = 0; i < animation.length; i++)
                {
                    let op = document.createElement("option");
                    action = mixer.clipAction(animation[i]);
                    actions[animation[i].name] = action;
                    op.text = animation[i].name;
                    op.value = animation[i].name;
                    animatioClip.appendChild(op);
                    
                }

                action = mixer.clipAction(animation[0]);
                    hasani = true;
                
                
                console.log(action);

            } catch (e) {
                hasani = false;
                console.log("No Animation");
            }

            
            HideMe();
            //model.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo
            preload.classList.remove("show");
            preload.classList.add("hide");

            controls.target = box.getCenter();
            controls.saveState();


            scene.add(model);

            ControlDist();

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("En progreso GLB");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (errorMessage) => { console.log(errorMessage); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        const parrotPosition = new THREE.Vector3(0, 0, 0);
        loader.load(this.MC_url, obj => onLoad(obj, parrotPosition), onProgress, onError);

    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {                    
                    child.material.wireframe = !child.material.wireframe ? true : false;          
            }
        }
        );
    }
}

////////////////////////////////////////////////////////////////////////


export default class App
{
   

    constructor ()
    {
    }

    init(url)
    {
        //url2 = "http//"+"visor.local:3000/models/gltf/f.glb"; 
        
        

        
        
        if (url ==="")
        {
            url2 = "models/re.glb";
        }
        else
        {
                url2 = url;
                
                
                if(!url2.startsWith('http'))
            {
                url2 = 'http://' + url2
            }

            if(checkURL(url2)==false)
            {
            // alert("El modelo a cargar no existe, porfavor verifique la dirección URL dada");
                
                let toat = '<span>El modelo no pudo ser cargado, verifique la URL. Modelo predefinido cargado</span>'
                M.toast({html:toat, classes:'rounded'})
                url2 = "models/re.glb";
            }
        }
        

        scene = new THREE.Scene();

        scene.background = new THREE.Color(color);

        this.OBJLoaderCreate()

        this.createCamera();
       
        this.loadModel();

        this.createControls();

        this.createLight();

        this.createRenderer();


        
        stats = new Stats();

        

        window.addEventListener('resize', this.onWindowsResize);

        container.appendChild(stats.dom);

        container.appendChild(renderer.domElement);

       this.GUI();
    }

    OBJLoaderCreate()
    {
        if (url2.endsWith('stl')) {
            objectLoader = new ModelCreatorSTL(url2)
            console.log("Caregando STL")
        } else if (url2.endsWith('glb')|| url2.endsWith('gltf')) {
            objectLoader = new ModelCreatorGLTF(url2);
            console.log("Caregando GLB")

        } else if (url2.endsWith('obj')) {
            objectLoader = new ModelCreatorOBJ(url2);
            console.log("Caregando OBJ")

        } else if (url2.endsWith('fbx')) {
            objectLoader = new ModelCreatorFBX(url2);
            console.log("Caregando FBX")

        } else {
            alert("Formato no soportado");
        }
        preload.classList.add("show");
    }

    update() 
    {       
        stats.update();

        controls.update();

        const delta = clock.getDelta();

        if (ani == true)
            mixers.forEach((mixer) => { mixer.update(delta); });
        
        if(rotation == true) {

                controls.autoRotate = true;
                controls.autoRotateSpeed = rotateSpeed;
                      
        }
        else
        {
            controls.autoRotate = false;
        }
    }

    render() 
    {
        renderer.render(scene, camera);
    }

    play() 
    {
        ani = true;
        renderer.setAnimationLoop(() => {
            this.update();
            this.render();
        })
    }

    stop()
    {
        ani = false;
    }

    onWindowsResize() {

        camera.aspect = container.clientWidth / container.clientHeight; // Darle un nuevo valor al ratio de aspectio para la nueva ventana creada

        camera.updateProjectionMatrix(); // update camera frustum

        renderer.setSize(container.clientWidth, container.clientHeight); // cambiar el tamanno de renderizado
    }

    createCamera() {

        const fov = 35;

        const aspect = container.clientWidth / container.clientHeight;

        const near = 0.1;

        const far = 10000;

        camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

        camera.position.set(0, 0, 10);

        CameraBox = new THREE.Box3().setFromObject(camera);
    }

    loadModel() {

        objectLoader.Execute();

    }

    CameraRePositioning() 
    {
        camera.position.set(0, 0, 10);
    }

    createLight() {

        ambientLight = new THREE.HemisphereLight(
            0xddeeff, // bright sky color
            0x202020, // dim ground color
            2, // intensity
        );

        mainLight = new THREE.DirectionalLight(0xffffff, 2);

        mainLight.position.set(10, 5, 10);

        scene.add(ambientLight, mainLight);
    }

    createRenderer() {

        renderer = new THREE.WebGLRenderer({ antialias: true }); 

        renderer.setSize(container.clientWidth, container.clientHeight);

        renderer.setPixelRatio(window.devicePixelRatio);

        renderer.physicallyCorrectLights = true;

        renderer.gammaFactor = 2.2;

        renderer.gammaOutput = true;
    }

    createControls() {
        controls = new THREE.OrbitControls(camera, container);
        controls.enablePan = false;
    }

    FBXWireframe()
    {

    }

    GUI(){
         ////////////////


         wire.addEventListener('click', ()=>{objectLoader.MaterialWireframe();});

         ////Animacion//////
         ani_iniciar.addEventListener('click', ()=>{try{
             if(!action.isRunning())
                 action.play(); ani=true;            
         }catch(e)
         {alert("El modelo cargado no posee animación")}});
 
         ani_detener.addEventListener('click', ()=>{try{
             if(action.isRunning())
                 action.stop();            
         }catch(e)
         {alert("El modelo cargado no posee animación")}});
 
         ani_reanudar.addEventListener('click', ()=>{ani = true});
 
         ani_pausar.addEventListener('click', ()=>{ani = false});
 
         ///Rotar///
         rot_iniciar.addEventListener('change', ()=>{rotation = !rotation ? true : false;});
 
         rot_velocidad.addEventListener('change',()=>{setInterval(()=>(rotateSpeed = parseFloat(rot_velocidad.value)),1)});
     
         rot_reiniciar.addEventListener('click',()=>{
             
            controls.reset();
            })

         ////Fondo////
         fondo.addEventListener('change',()=>{setInterval(()=>(scene.background = new THREE.Color(parseInt('0x' + fondo.value))),1);
         });

                 
 
         ///Luz Directa////
         ld_intensidad.addEventListener('change',()=>{setInterval(()=>(mainLight.intensity = parseFloat(ld_intensidad.value)),1);});
 
         ld_color.addEventListener('change',()=>{setInterval(()=>(mainLight.color.setHex(parseInt('0x' + ld_color.value)) ),1);
     });
 
         ld_posX.addEventListener('change',()=>(setInterval(()=>(mainLight.position.x = parseInt(ld_posX.value)),1)));
         
         ld_posY.addEventListener('change',()=>(setInterval(()=>(mainLight.position.y = parseInt(ld_posY.value)),1)));
 
         ld_posZ.addEventListener('change',()=>(setInterval(()=>(mainLight.position.z = parseInt(ld_posZ.value)),1)));
 
                 ///Luz Ambiental////
         la_intensidad.addEventListener('change',()=>{setInterval(()=>(ambientLight.intensity = parseInt(la_intensidad.value)),1)})
 
         la_color.addEventListener('change',()=>{setInterval(()=>(ambientLight.color.setHex(parseInt('0x' + la_color.value)) ),1);
     });
 
         la_color_secundario.addEventListener('change',()=>{setInterval(()=>(ambientLight.groundColor.setHex(parseInt('0x' + la_color_secundario.value)) ),1);
     });
 
         la_posX.addEventListener('change',()=>(setInterval(()=>(ambientLight.position.x = parseInt(la_posX.value)),1)));
         
         la_posY.addEventListener('change',()=>(setInterval(()=>(ambientLight.position.y = parseInt(la_posY.value)),1)));
 
         la_posZ.addEventListener('change',()=>(setInterval(()=>(ambientLight.position.z = parseInt(la_posZ.value)),1)));
 
        
         animatioClip.addEventListener('change',()=>{ action.fadeOut(fadeTime); action = actions[animatioClip.value]; action.reset().fadeIn(fadeTime).play();});

         if("createEvent" in document)
         {
             var evt = document.createEvent("HTMLEvents");
             evt.initEvent("change", false, true);
             fondo.dispatchEvent(evt);
             
             rot_velocidad.dispatchEvent(evt);

             la_color.dispatchEvent(evt);
             la_color_secundario.dispatchEvent(evt);            
             la_intensidad.dispatchEvent(evt);
             la_posX.dispatchEvent(evt);
             la_posY.dispatchEvent(evt);
             la_posZ.dispatchEvent(evt);

             ld_color.dispatchEvent(evt);
             ld_intensidad.dispatchEvent(evt);
             ld_posX.dispatchEvent(evt);
             ld_posY.dispatchEvent(evt);
             ld_posZ.dispatchEvent(evt);


         }

}



}


function checkURL(url)
{


    let x = new XMLHttpRequest();

    x.open('HEAD', url, false);
    x.send();

    return x.status == "404"? false : true;
}

function HideMe()
{
    if(hasani == false)
    {
        animatioWrapper.classList.remove("show");
        animatioWrapper.classList.add("hide");
    }
    else
    {
        animatioWrapper.classList.remove("hide");
        animatioWrapper.classList.add("show");                
    }
}

function ControlDist()
{
    controls.minDistance = box.max.y;
}



