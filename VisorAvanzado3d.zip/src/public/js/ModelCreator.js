
class ModelCreator {

    MC_url;

    constructor (url)
    {
        this.MC_url = url;
    }

   
    Execute() {}
    MaterialWireframe(){}
}

class ModelCreatorOBJ extends ModelCreator {

    mtlLoader = new THREE.MTLLoader();
    loader = new THREE.OBJLoader();

    constructor (url)
    {
        super(url);
    }

   

    Execute() {
        
        
        var mtlURL = this.MC_url.replace("obj","mtl");
        console.log(mtlURL);
        const initialpos = new THREE.Vector3(0, 0, 0);
        var Mtlcarga = false;

        Mtlcarga = existeURL(mtlURL);
        
        
        if(Mtlcarga == true)
       {
            this.MTLLoad(mtlURL,this.loader,initialpos);
       }
       else
        {
            this.OBJLoad(this.loader,initialpos);
        }

        


        // the loader will report the loading progress to this function
       

        

    }

    MTLLoad(mtlURL,loader,initialpos)
    {
    
        this.mtlLoader.load(mtlURL, function(material) {
            
            material.preload();
            loader.setMaterials(material);

            const onLoad = (obj, position) => {
                console.log("Ejecutando")
                obj.position.copy(position);

                box = new THREE.Box3().setFromObject(obj);
                

                console.log(mtlURL);

                model = obj;
                       
                obj.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo

                

                while(box.getParameter(camera.position).z < 9)
                camera.position.z += 50;

                action = null;

                preload.classList.remove("show");
                preload.classList.add("hide");
                scene.add(obj);

            };
            loader.load(url, obj => onLoad(obj, initialpos), onProgress, onError);
            }

            );
       

            const onProgress = () => {
                console.log("Cargando MTL....");
            };



            // the loader will send any error messages to this function, and we'll log
            // them to to console
            const onError = (errorMessage) => { alert("Error al cargar el archivo 3D"); };

            // load the first model. Each model is loaded asynchronously,
            // so don't make any assumption about which one will finish loading first
}

    OBJLoad(loader,initialpos)
    {           
            const onLoad = (obj, position) => {
                console.log("Ejecutando")

                box = new THREE.Box3().setFromObject(obj);


                //camera.position.z = box.max.z * 20;

                console.log(obj);

                model = obj;

                obj.position.copy(position);

                //obj.scale.set(0.2, 0.2, 0.2);

                
                obj.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo

                //camera.position.z = box.distanceToPoint(camera.position);
                while(box.getParameter(camera.position).z < 9)
                camera.position.z += 50;

                action = null;

                preload.classList.remove("show");
                preload.classList.add("hide");
                scene.add(obj);

            };    
            // the loader will report the loading progress to this function
              
            

            const onProgress = () => {
                                
                console.log("Cargando OBJ....");
            };



            // the loader will send any error messages to this function, and we'll log
            // them to to console
            const onError = (errorMessage) => { alert("Error al cargar el archivo 3D"); };

            // load the first model. Each model is loaded asynchronously,
            // so don't make any assumption about which one will finish loading first
            loader.load(url , obj => onLoad(obj, initialpos), onProgress, onError);
    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {

                
                 
                    child.material.wireframe = !child.material.wireframe ? true : false;
                    
        
                
            }
        }
        );
            
    }

}

class ModelCreatorFBX extends ModelCreator {


    Execute() {
        var loader = new THREE.FBXLoader();

        const onLoad = (obj, position) => {

           

            CameraRePositioning();
            obj.position.copy(position);
            box = new THREE.Box3().setFromObject(obj);

            console.log("Cargando Modelo FBX");


            //camera.position.z = box.max.z * 20;

            obj.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo

            //obj.material = new THREE.MeshBasicMaterial({ color: 0xf90338, wireframe: true });

            //CameraRePositioning(box.max.z + 50);
            while(box.getParameter(camera.position).z < 9)
            camera.position.z += 50;
            
            try {
                const mixer = new THREE.AnimationMixer(obj);
                mixers.push(mixer);
                const animation = obj.animations[0];

                action = mixer.clipAction(animation);
            } catch (e) {
                hasani = false
            }

            model = obj;

            preload.classList.remove("show");
            preload.classList.add("hide");

            scene.add(obj);

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("Cargando FBX....");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (e) => { 
            alert('On Error');
            alert(e); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        const parrotPosition = new THREE.Vector3(0, 0, 0);
        loader.load(this.MC_url, obj => onLoad(obj, parrotPosition), onProgress, onError);

    }

    MaterialWireframe() 
    {
        model.traverse(function (child) {
            if ( child.material ) {

                
                    if(child.material.wireframe == false)
                    child.material.wireframe = true;
                    else
                    child.material.wireframe = false;
        
                
            }
        }
        );
    }

}

class ModelCreatorSTL extends ModelCreator {


    Execute() {
        var material = new THREE.MeshLambertMaterial({ color: 0xffffff });
        var loader = new THREE.STLLoader();

        const onLoad = (obj) => {

           
            CameraRePositioning();
            var meshMaterial = material;
            console.log(obj.hasColors);
            if (obj.hasColors) {
                meshMaterial = new THREE.MeshPhongMaterial({ opacity: obj.alpha, vertexColors: THREE.VertexColors });
            }

            console.log("Algo");

            var mesh = new THREE.Mesh(obj, meshMaterial);

            mesh.position.set(0.5, 0.2, 0);
            mesh.rotation.set(-Math.PI / 2, Math.PI / 2, 0);
            mesh.scale.set(0.3, 0.3, 0.3);

            model = mesh;

            box = new THREE.Box3().setFromObject(mesh);

            while(box.getParameter(camera.position).z < 9)
            camera.position.z += 50;

            preload.classList.remove("show");
            preload.classList.add("hide");

            scene.add(mesh);

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("cargando STL");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (errorMessage) => { alert(errorMessage); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        loader.load(this.MC_url, obj => onLoad(obj), onProgress, onError);

    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {                    
                    child.material.wireframe = !child.material.wireframe ? true : false;          
            }
        }
        );
    }

}

class ModelCreatorGLTF extends ModelCreator {


    Execute() {
        var loader = new THREE.GLTFLoader();
        var dracoLoader = new THREE.DRACOLoader(loader);
          
        loader.setDRACOLoader(dracoLoader);
    
        

        const onLoad = (obj, position) => {

            

            CameraRePositioning();
            console.log(obj);

            model = obj.scene.children[0];
            model.position.copy(position);

            
            box = new THREE.Box3().setFromObject(model);
            model.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo


            //camera.position.set(0,0,box.max.z * 4);
            while(box.getParameter(camera.position).z < 2)
                camera.position.z += 50;
            //CameraRePositioning(box.max.z + 100); //nuevo agregar

            origin = model.material;

            try {
                const animation = obj.animations[0];

                const mixer = new THREE.AnimationMixer(model);
                mixers.push(mixer);

                action = mixer.clipAction(animation);
                console.log(action);

            } catch (e) {
                hasani = false;
                console.log("No Animation");
            }

            SetMaterial(0);

            //model.position.y = box.getCenter().y * -1; // mover el centro del objeto al medio del mismo
            preload.classList.remove("show");
            preload.classList.add("hide");
            scene.add(model);

        };

        // the loader will report the loading progress to this function
        const onProgress = () => {
            console.log("En progreso GLB");
        };



        // the loader will send any error messages to this function, and we'll log
        // them to to console
        const onError = (errorMessage) => { console.log(errorMessage); };

        // load the first model. Each model is loaded asynchronously,
        // so don't make any assumption about which one will finish loading first
        const parrotPosition = new THREE.Vector3(0, 0, 0);
        loader.load(this.MC_url, obj => onLoad(obj, parrotPosition), onProgress, onError);

    }

    MaterialWireframe()
    {
        model.traverse(function (child) {
            if ( child.material ) {                    
                    child.material.wireframe = !child.material.wireframe ? true : false;          
            }
        }
        );
    }
}



export {ModelCreator, ModelCreatorFBX, ModelCreatorGLTF, ModelCreatorOBJ, ModelCreatorSTL};